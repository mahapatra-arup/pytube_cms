=========
Dashboard
=========

.. toctree::
   :maxdepth: 2

   dashboard_custom
   dashboard_modules
   dashboard_custom_module
