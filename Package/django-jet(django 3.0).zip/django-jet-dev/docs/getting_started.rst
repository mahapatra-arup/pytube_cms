===============
Getting Started
===============

Contents:

.. toctree::
   :maxdepth: 2

   install
   install_dashboard
