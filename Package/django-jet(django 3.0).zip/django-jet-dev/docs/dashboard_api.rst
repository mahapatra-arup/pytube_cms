=============
Dashboard API
=============

This page describes the API of the dashboard and dashboard modules.

.. _Dashboard:

Dashboard
---------

.. autoclass:: jet.dashboard.dashboard.Dashboard
   :members:

.. _Dashboard Module:

DashboardModule
---------------

.. autoclass:: jet.dashboard.modules.DashboardModule
   :members: