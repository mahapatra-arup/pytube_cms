=============
Configuration
=============

Contents:

.. toctree::
   :maxdepth: 2

   config_file
   autocomplete
   compact_inline
   filters
